using System.Globalization;
using System.Net;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

/// <summary>Una sessione = un client che ha fatto l'handshake. Ognuna ha la sua chiave.</summary>
class Session
{
    public string Id = "";
    public byte[] Key;
    public DateTime LastUse = DateTime.Now;   // per la scadenza (401)
}

class Program
{
    // Indirizzo del server. Se lo cambi, cambialo anche nel Client (Client/Program.cs).
    const string Url = "http://localhost:5000/";

    // Dopo quanto tempo senza messaggi una sessione scade
    static readonly TimeSpan SessionTimeout = TimeSpan.FromMinutes(10);

    // Dati condivisi da tutte le richieste. Le richieste vengono gestite in parallelo,
    // quindi chi legge o modifica questi dati lo fa dentro lock(locker).
    static readonly object locker = new object();
    static Dictionary<string, Session> sessions = new Dictionary<string, Session>();
    static JsonArray readings = new JsonArray();   // tutte le misure ricevute
    static string dataFile = "";                   // file JSON dove vengono salvate

    // Formato del file: JSON indentato (leggibile) e senza trasformare + ' e accenti in \u002B...
    static readonly JsonSerializerOptions FileFormat = new JsonSerializerOptions
    {
        WriteIndented = true,
        Encoder = Crypto.Readable.Encoder
    };

    static void Main()
    {
        // punto decimale sempre con il punto (anche se Windows e' in italiano)
        CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
        CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

        // Le misure ricevute vengono salvate nel file Server/data/readings.json.
        // Il programma gira in Server/bin/Debug/net8.0: risalgo di 3 cartelle per arrivare a Server/
        string serverFolder = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", ".."));
        dataFile = Path.Combine(serverFolder, "data", "readings.json");
        Directory.CreateDirectory(Path.GetDirectoryName(dataFile));
        if (File.Exists(dataFile))
            readings = JsonNode.Parse(File.ReadAllText(dataFile)).AsArray();   // misure dei giri precedenti

        if (!Directory.Exists(SchemaValidator.SchemasFolder))
            Console.WriteLine("ATTENZIONE: cartella degli schemi non trovata: " + SchemaValidator.SchemasFolder);

        HttpListener listener = new HttpListener();
        listener.Prefixes.Add(Url);
        try
        {
            listener.Start();
        }
        catch (HttpListenerException ex)
        {
            Console.WriteLine("Impossibile avviare il server su " + Url);
            Console.WriteLine("Errore: " + ex.Message + " (codice " + ex.ErrorCode + ")");
            Console.WriteLine("- Porta gia' usata (per esempio un altro server ancora aperto)? Chiudilo,");
            Console.WriteLine("  oppure cambia la porta in Url qui e nel Client.");
            Console.WriteLine("- 'Accesso negato'? Avvia Visual Studio come amministratore.");
            Console.WriteLine("Premi Invio per chiudere.");
            Console.ReadLine();
            return;
        }

        Console.WriteLine("Server FrigoTrack in ascolto su " + Url);
        Console.WriteLine("Schemi letti da   " + SchemaValidator.SchemasFolder);
        Console.WriteLine("Misure salvate in " + dataFile + " (" + readings.Count + " gia' presenti)");
        Console.WriteLine("Chiudi la finestra (o Ctrl+C) per fermarlo.");
        Console.WriteLine();

        while (true)
        {
            HttpListenerContext context = listener.GetContext();   // aspetta la prossima richiesta
            Task.Run(() => HandleRequest(context));                 // e la gestisce in parallelo
        }
    }

    // ===================================================================
    //  Smistamento: ogni richiesta arriva qui
    // ===================================================================
    static void HandleRequest(HttpListenerContext context)
    {
        try
        {
            string path = context.Request.Url.AbsolutePath;
            string body = new StreamReader(context.Request.InputStream, Encoding.UTF8).ReadToEnd();

            if (context.Request.HttpMethod != "POST")
                Send(context, 404, ErrorJson("endpoint non trovato", ""));
            else if (path == "/api/handshake")
                Handshake(context, body);
            else if (path == "/api/telemetry" || path == "/api/readings" || path == "/api/close")
                EncryptedRequest(context, path, body);
            else
                Send(context, 404, ErrorJson("endpoint non trovato", ""));
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERRORE interno: " + ex.Message);
            try { Send(context, 500, ErrorJson("errore interno del server", "")); } catch { }
        }
    }

    // ===================================================================
    //  POST /api/handshake   (in chiaro: la chiave non esiste ancora)
    // ===================================================================
    static void Handshake(HttpListenerContext context, string body)
    {
        // 1) il messaggio rispetta lo schema handshake-request?
        //    Lo schema controlla che p e g siano quelli del gruppo 14 di RFC 3526 ("const")
        //    e che A sia un numero esadecimale da 2 a 512 cifre ("pattern").
        SchemaError error = SchemaValidator.Validate(body, "handshake-request");
        if (error != null)
        {
            Send(context, 400, ErrorJson(error.Message, error.Field));
            return;
        }

        JsonNode request = JsonNode.Parse(body);
        BigInteger A = Crypto.FromHex((string)request["A"]);

        // 2) unico controllo che JSON Schema non puo' fare (e' un confronto tra numeri da 2048 bit):
        //    A deve essere minore di p-1, altrimenti il segreto condiviso sarebbe prevedibile
        if (A >= Crypto.P - 1)
        {
            Send(context, 400, ErrorJson("chiave pubblica A troppo grande", "A"));
            return;
        }

        // 3) Diffie-Hellman lato server
        BigInteger b = Crypto.NewSecret();        // segreto del server: non esce mai da qui
        BigInteger B = Crypto.PublicKey(b);       // B = g^b mod p
        byte[] key = Crypto.SharedKey(A, b);      // K = A^b mod p  ->  chiave AES

        // 4) nuova sessione con un identificativo casuale
        Session session = new Session();
        session.Id = Convert.ToHexString(RandomNumberGenerator.GetBytes(8)).ToLower();
        session.Key = key;
        lock (locker)
        {
            sessions[session.Id] = session;
        }
        Log("handshake: nuova sessione " + session.Id);

        JsonObject response = new JsonObject();
        response["session_id"] = session.Id;
        response["B"] = Crypto.ToHex(B);
        Send(context, 200, response.ToJsonString());
    }

    // ===================================================================
    //  Richieste cifrate: /api/telemetry, /api/readings, /api/close
    // ===================================================================
    static void EncryptedRequest(HttpListenerContext context, string path, string body)
    {
        // 1) la busta ha la forma giusta?
        SchemaError error = SchemaValidator.Validate(body, "envelope");
        if (error != null)
        {
            Send(context, 400, ErrorJson(error.Message, error.Field));
            return;
        }
        JsonNode envelope = JsonNode.Parse(body);
        string sessionId = (string)envelope["session_id"];

        // 2) la sessione esiste? e' scaduta?
        Session session;
        lock (locker)
        {
            sessions.TryGetValue(sessionId, out session);
        }
        if (session == null)
        {
            Send(context, 404, ErrorJson("sessione inesistente: serve un nuovo handshake", ""));
            return;
        }
        if (DateTime.Now - session.LastUse > SessionTimeout)
        {
            lock (locker)
            {
                sessions.Remove(sessionId);
            }
            Send(context, 401, ErrorJson("sessione scaduta: serve un nuovo handshake", ""));
            return;
        }

        // 3) PRIMA decifro. Se il tag non torna rispondo 400 e non elaboro nulla.
        string json = Crypto.Decrypt(session.Key, (string)envelope["ciphertext"], (string)envelope["tag"]);
        if (json == null)
        {
            Log("busta manomessa o non decifrabile (sessione " + sessionId + ")");
            Send(context, 400, ErrorJson("busta non decifrabile o manomessa", ""));
            return;
        }
        session.LastUse = DateTime.Now;

        // 4) POI valido il messaggio decifrato con il suo schema
        string schemaName = "";
        if (path == "/api/telemetry") schemaName = "telemetry";
        if (path == "/api/readings") schemaName = "readings-request";
        if (path == "/api/close") schemaName = "close-request";

        error = SchemaValidator.Validate(json, schemaName);
        if (error != null)
        {
            Log("messaggio rifiutato dallo schema " + schemaName + ": campo '" + error.Field + "' -> " + error.Message);
            SendEncrypted(context, 400, session, ErrorJson(error.Message, error.Field));
            return;
        }

        // 5) elaboro il messaggio
        JsonObject message = JsonNode.Parse(json).AsObject();
        if (path == "/api/telemetry") Telemetry(context, session, message);
        if (path == "/api/readings") Readings(context, session, message);
        if (path == "/api/close") Close(context, session);
    }

    // ---------------- /api/telemetry: salva la misura e controlla l'allarme ----------------
    static void Telemetry(HttpListenerContext context, Session session, JsonObject measure)
    {
        string sensorId = (string)measure["sensor_id"];
        string cargo = (string)measure["cargo_type"];
        double temperature = (double)measure["temperature_c"];

        // Controllo degli allarmi: se c'e' un problema scrivo il motivo in alarmMessage.
        // Per aggiungere un allarme basta aggiungere un altro "if" come questo.
        string alarmMessage = "";
        SafeRange(cargo, out double min, out double max);
        if (temperature < min || temperature > max)
            alarmMessage = "temperatura " + temperature + " C fuori intervallo " + min + ".." + max + " C (" + cargo + ")";

        bool alarm = alarmMessage != "";
        string now = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'");

        // SALVATAGGIO nel file JSON: la misura inviata dal client, piu' l'ora di arrivo e l'esito
        // dell'allarme, viene aggiunta all'elenco e il file data/readings.json viene riscritto
        measure["received_at"] = now;
        measure["alarm"] = alarm;
        int total;
        lock (locker)
        {
            readings.Add(measure);
            File.WriteAllText(dataFile, readings.ToJsonString(FileFormat));
            total = readings.Count;
        }

        // risposta (ack)
        JsonObject ack = new JsonObject();
        ack["status"] = "ok";
        ack["sensor_id"] = sensorId;
        ack["received_at"] = now;
        ack["alarm"] = alarm;
        if (alarm)
            ack["alarm_message"] = alarmMessage;

        Log(sensorId + ": " + temperature + " C -> salvata in readings.json (totale: " + total + ")"
            + (alarm ? "   *** ALLARME: " + alarmMessage : ""));
        SendEncrypted(context, 200, session, ack.ToJsonString());
    }

    // Intervallo di sicurezza della temperatura per ogni tipo di merce (gradi Celsius)
    static void SafeRange(string cargo, out double min, out double max)
    {
        switch (cargo)
        {
            case "food": min = 0; max = 4; break;
            case "pharma": min = 2; max = 8; break;
            case "frozen": min = -25; max = -18; break;
            default: min = -40; max = 40; break;   // non succede: lo schema ammette solo i tre tipi sopra
        }
    }

    // ---------------- /api/readings: restituisce le misure di un sensore ----------------
    static void Readings(HttpListenerContext context, Session session, JsonObject request)
    {
        string sensorId = (string)request["sensor_id"];

        // intervallo di tempo facoltativo: se "from" o "to" mancano non c'e' limite
        DateTimeOffset from = DateTimeOffset.MinValue;
        DateTimeOffset to = DateTimeOffset.MaxValue;
        if (request["from"] != null) from = DateTimeOffset.Parse((string)request["from"]);
        if (request["to"] != null) to = DateTimeOffset.Parse((string)request["to"]);

        JsonArray found = new JsonArray();
        lock (locker)
        {
            foreach (JsonNode reading in readings)
            {
                DateTimeOffset time = DateTimeOffset.Parse((string)reading["timestamp"]);
                if ((string)reading["sensor_id"] == sensorId && time >= from && time <= to)
                    found.Add(reading.DeepClone());   // copia: un nodo JSON puo' stare in un solo elenco
            }
        }

        JsonObject response = new JsonObject();
        response["sensor_id"] = sensorId;
        response["count"] = found.Count;
        response["readings"] = found;

        Log("readings: " + found.Count + " misure di " + sensorId);
        SendEncrypted(context, 200, session, response.ToJsonString());
    }

    // ---------------- /api/close: chiude la sessione e cancella la chiave ----------------
    static void Close(HttpListenerContext context, Session session)
    {
        lock (locker)
        {
            sessions.Remove(session.Id);   // da ora questa sessione non esiste piu' (404)
        }

        JsonObject response = new JsonObject();
        response["status"] = "closed";
        SendEncrypted(context, 200, session, response.ToJsonString());   // cifro PRIMA di cancellare la chiave

        Array.Clear(session.Key);   // cancello la chiave dalla memoria
        Log("sessione " + session.Id + " chiusa, chiave cancellata");
    }

    // ===================================================================
    //  Invio delle risposte
    // ===================================================================

    // Risposta in chiaro (usata quando non c'e' una chiave valida con cui cifrare)
    static void Send(HttpListenerContext context, int status, string json)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(json);
        context.Response.StatusCode = status;
        context.Response.ContentType = "application/json; charset=utf-8";
        context.Response.ContentLength64 = bytes.Length;
        context.Response.OutputStream.Write(bytes, 0, bytes.Length);
        context.Response.Close();
    }

    // Risposta cifrata: il JSON viene messo in una busta
    static void SendEncrypted(HttpListenerContext context, int status, Session session, string json)
    {
        Send(context, status, Crypto.Seal(session.Id, session.Key, json));
    }

    // Messaggio di errore: {"error": "...", "field": "..."}  (field solo se si sa quale campo e' sbagliato)
    static string ErrorJson(string message, string field)
    {
        JsonObject error = new JsonObject();
        error["error"] = message;
        if (field != "") error["field"] = field;
        return error.ToJsonString(Crypto.Readable);
    }

    static void Log(string text)
    {
        Console.WriteLine("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + text);
    }
}
