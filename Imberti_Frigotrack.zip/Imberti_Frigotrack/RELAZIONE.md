# Relazione – scelte tecniche e limiti noti

## Scelte tecniche

**Struttura.** Due progetti console .NET 8 indipendenti, Server e Client, ciascuno con la propria soluzione. Il codice è volutamente semplice: niente programmazione asincrona, classi minime, e tutto il server in un solo file che si legge dall'alto verso il basso. Gli schemi stanno in un'unica cartella `schemas/`, condivisa dai due progetti. Il prezzo della separazione è che `Crypto.cs` e `SchemaValidator.cs` sono copiati in entrambi.

**Server HTTP.** Uso `HttpListener`, incluso in .NET. Un ciclo aspetta le richieste e passa ognuna a un `Task` separato, così più client lavorano insieme. Sessioni e misure sono condivise tra i task, quindi ogni accesso è protetto da un `lock`.

**Diffie-Hellman.** Gruppo n. 14 dell'RFC 3526 (primo da 2048 bit, `g = 2`). I calcoli `A = g^a mod p` e `K = B^a mod p` sono fatti con `BigInteger.ModPow`. I segreti sono 256 bit casuali presi da `RandomNumberGenerator`. `K` è di 2048 bit, mentre AES-256 richiede 32 byte: la chiave è quindi `SHA-256(K)`.

**Cifratura.** AES-256-GCM, incluso in .NET: cifra e autentica, quindi una busta modificata viene scoperta dal tag. Il nonce è casuale per ogni messaggio e viaggia davanti al testo cifrato, così la busta ha solo i tre campi richiesti.

**JSON Schema.** La validazione la fa la libreria **JsonSchema.Net** (pacchetto NuGet, draft 2020-12). Legge i 10 file di `schemas/` e restituisce posizione e motivo di ogni errore, con messaggi in italiano. Il codice non contiene controlli sui singoli campi: anche il controllo che `p` e `g` siano quelli del gruppo 14 è nello schema (`const`). L'unico controllo rimasto nel codice è che la chiave pubblica `A` sia minore di `p-1`: è un confronto tra numeri da 2048 bit scritti in esadecimale, che JSON Schema non sa fare. Il client valida ogni messaggio prima di cifrarlo; il server lo valida dopo averlo decifrato.

**Ordine dei controlli sul server.** Prima lo schema della busta, poi la sessione (404 se non esiste, 401 se è scaduta), poi la decifratura (400 se il tag non torna), poi lo schema del messaggio (400 cifrato, con il campo sbagliato), infine l'elaborazione. Niente viene elaborato prima che la decifratura sia riuscita.

**Salvataggio.** Ogni misura accettata, con l'ora di arrivo e l'esito dell'allarme, viene aggiunta a un elenco. Il server riscrive poi tutto il file `Server/data/readings.json`. Al riavvio il file viene ricaricato, e `/api/readings` legge da lì.

**Test.** Nove test nel client (voce 3 del menu), eseguiti contro il server vero. Coprono i cinque casi richiesti, più allarme, consultazione, chiusura e handshake rifiutato dallo schema.

## Limiti noti

1. **Nessuna autenticazione delle parti.** Diffie-Hellman da solo protegge da chi ascolta, non da chi si mette in mezzo e fa due handshake separati (man-in-the-middle). Servirebbe una firma del server o una chiave pre-condivisa per ogni sensore.
2. **Nessuna protezione dal replay.** Una busta catturata può essere reinviata e verrebbe accettata di nuovo. Si risolve facendo ricordare al server i tag già visti, oppure con un contatore progressivo.
3. **Metadati visibili.** Restano in chiaro gli endpoint, la dimensione dei messaggi, gli orari, il `session_id` e gli errori che precedono la decifratura.
4. **Nessun limite al traffico.** Chiunque può aprire molte sessioni o inviare richieste molto grandi.
5. **Il `sensor_id` non è legato alla sessione.** Un sensore con una sessione valida può dichiararsi un altro sensore.
6. **Salvataggio semplice.** Il file viene riscritto per intero a ogni misura: va bene per un prototipo, non per migliaia di sensori.
7. **Codice duplicato.** `Crypto.cs` e `SchemaValidator.cs` vanno tenuti uguali a mano nei due progetti.
8. **Errori dettagliati.** Indicare campo e motivo aiuta chi sviluppa, ma in produzione conviene esporre meno informazioni.
