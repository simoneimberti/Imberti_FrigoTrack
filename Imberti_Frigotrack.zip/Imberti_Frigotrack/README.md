# FrigoTrack – Telemetria sicura per la catena del freddo

Prototipo client-server in cui dei sensori di temperatura inviano misure in JSON a un server HTTP.
Il canale resta **HTTP** (niente HTTPS): la sicurezza la fa l'applicazione.

- La chiave si concorda con **Diffie-Hellman** (scritto a mano) e **non viaggia mai in rete**.
- I messaggi viaggiano cifrati con **AES-256-GCM**, che scopre anche le manomissioni.
- Ogni messaggio è validato con **JSON Schema**: le regole stanno nei file di `schemas/` e le applica la libreria **JsonSchema.Net**. Nel codice non ci sono controlli sui singoli campi.
- Il server **salva le misure ricevute** nel file JSON `Server/data/readings.json`.

C# / .NET 8. **Due progetti separati**, ognuno con la sua soluzione: Server e Client.
Il server usa `HttpListener`, già incluso in .NET. L'unico pacchetto NuGet è `JsonSchema.Net` (versione 7.3.1), che Visual Studio scarica da solo.

## Struttura

```
FrigoTrack/
├── schemas/                    un file JSON Schema per ogni tipo di messaggio (10 file), usati da entrambi
├── Server/                     PROGETTO SERVER
│   ├── Server.sln              si apre da solo in Visual Studio
│   ├── Program.cs              tutto il server: avvio, endpoint, sessioni, allarmi, salvataggio
│   ├── Crypto.cs               Diffie-Hellman e AES-GCM
│   ├── SchemaValidator.cs      validazione con JSON Schema (libreria JsonSchema.Net)
│   └── data/readings.json      le misure salvate (lo crea il server)
├── Client/                     PROGETTO CLIENT
│   ├── Client.sln              si apre da solo in Visual Studio
│   ├── Program.cs              menu, i 3 sensori, la demo
│   ├── Connection.cs           handshake e invio dei messaggi cifrati
│   ├── Tests.cs                i 9 test
│   ├── Crypto.cs               uguale a quello del Server
│   └── SchemaValidator.cs      uguale a quello del Server
└── README.md, RELAZIONE.md, STUDIO.md
```

> `Crypto.cs` e `SchemaValidator.cs` sono **uguali** nei due progetti, perché i progetti sono separati.
> Se ne modifichi uno, copia la modifica nell'altro.
> Gli schemi stanno in una sola cartella, `schemas/`, e compaiono in Visual Studio in entrambi i progetti, sotto la voce *schemas*.

## Avvio

Serve il **.NET 8 SDK**. La prima volta serve Internet, perché Visual Studio deve scaricare il pacchetto `JsonSchema.Net`.

### Da Visual Studio 2022 (due finestre)
1. Apri `Server/Server.sln` e premi **F5**. Nella console compare `Server FrigoTrack in ascolto su http://localhost:5000/` e il percorso del file delle misure.
2. Apri una **seconda** finestra di Visual Studio con `Client/Client.sln` e premi **F5**. Dal menu scegli:
   - `1` avvia i 3 sensori (10 misure ciascuno, una ogni 2 secondi);
   - `2` demo: una misura valida e una non valida, mostrando cosa viaggia in rete;
   - `3` esegue i test.
3. Le misure ricevute sono in `Server/data/readings.json`: in Visual Studio è sotto *data* nel progetto Server.

### Da terminale
```bash
cd Server && dotnet run      # primo terminale: lascialo aperto
cd Client && dotnet run      # secondo terminale: compare il menu
```

Per cambiare porta modifica `Url` in `Server/Program.cs` **e** in `Client/Program.cs`.
Se il server non parte, la sua finestra mostra il motivo (per esempio porta già occupata) e cosa fare.

---

## Protocollo

Due fasi: **handshake** (produce la chiave) e poi **messaggi cifrati**.

### Diagramma di sequenza

```mermaid
sequenceDiagram
    participant C as Client (sensore)
    participant S as Server

    Note over C: sceglie un segreto casuale a<br/>calcola A = g^a mod p
    C->>S: POST /api/handshake {p, g, A} in chiaro
    Note over S: valida con handshake-request.schema.json<br/>sceglie un segreto casuale b<br/>calcola B = g^b mod p<br/>calcola K = A^b mod p<br/>chiave AES = SHA-256(K)<br/>crea il session_id
    S-->>C: 200 {session_id, B} in chiaro
    Note over C: calcola K = B^a mod p<br/>chiave AES = SHA-256(K)
    Note over C,S: stessa chiave da entrambe le parti, mai trasmessa

    Note over C: valida la misura con telemetry.schema.json<br/>poi la cifra
    C->>S: POST /api/telemetry (busta cifrata con la misura)
    Note over S: 1 valida la busta (envelope.schema.json)<br/>2 trova la sessione<br/>3 decifra e verifica il tag<br/>4 valida la misura (telemetry.schema.json)<br/>5 controlla l'allarme e SALVA in readings.json
    S-->>C: 200 (busta cifrata con ack ed eventuale allarme)

    C->>S: POST /api/close (busta cifrata)
    S-->>C: 200 (busta cifrata), poi il server cancella la chiave
```

Gruppo Diffie-Hellman: n. 14 dell'RFC 3526 (primo `p` da 2048 bit, `g = 2`). I numeri grandi viaggiano come testo esadecimale.
Che `p` e `g` siano proprio quelli del gruppo 14 lo controlla lo schema `handshake-request`, con `const`.

### Endpoint (tutti POST)

| Endpoint | Corpo della richiesta | Risposta |
|---|---|---|
| `/api/handshake` | `{p, g, A}` in chiaro | `{session_id, B}` in chiaro |
| `/api/telemetry` | busta con la misura | busta con l'ack (ed eventuale allarme); la misura viene salvata in `readings.json` |
| `/api/readings` | busta con `{sensor_id, from?, to?}` | busta con `{sensor_id, count, readings}` letti dalle misure salvate |
| `/api/close` | busta con `{"action":"close"}` | busta con `{"status":"closed"}`; poi sessione e chiave cancellate |

### Codici HTTP

| Codice | Quando |
|---|---|
| 200 | tutto bene |
| 400 | messaggio rifiutato dallo schema (busta, handshake o messaggio decifrato) · decifratura o tag falliti (busta manomessa) |
| 401 | sessione scaduta (nessun messaggio da più di 10 minuti) |
| 404 | sessione inesistente (anche dopo `/api/close`) · endpoint sconosciuto o metodo diverso da POST |

Gli errori **dopo** la decifratura viaggiano cifrati. Quelli **prima** (busta malformata, sessione inesistente, tag sbagliato) sono in chiaro, perché non c'è una chiave valida con cui cifrarli.

### La busta

```json
{ "session_id": "a3f9c2e1b7d04c58", "ciphertext": "mH3t...Base64...==", "tag": "8dK2...Base64...==" }
```

- `session_id`: l'unico dato in chiaro; serve al server per trovare la chiave giusta.
- `ciphertext`: Base64 di *nonce (12 byte casuali, nuovo per ogni messaggio) + testo cifrato*.
- `tag`: Base64 del tag di autenticazione GCM (16 byte): se cambia anche un solo bit, la decifratura fallisce.

Regola del server: **prima decifra, poi valida**. Se la decifratura o il tag falliscono risponde 400 e non elabora nulla.

### Validazione con JSON Schema

`SchemaValidator.Validate(json, "nome-schema")` carica `schemas/nome-schema.schema.json` e lo passa alla libreria **JsonSchema.Net** (draft 2020-12), che applica tutte le regole dello schema.
Se il messaggio non è valido, la libreria indica **dove** (il campo) e **perché**; i messaggi sono in italiano:

```json
{ "error": "99 è maggiore di 40", "field": "temperature_c" }
{ "error": "Il valore deve coincidere con uno dei valori specificati nell'enum", "field": "cargo_type" }
{ "error": "Le proprietà richieste [\"timestamp\"] non sono presenti" }
```

Per cambiare una regola si modifica lo schema, non il codice.

| Messaggio | File in `schemas/` | Chi lo valida |
|---|---|---|
| Richiesta handshake | `handshake-request.schema.json` | server |
| Risposta handshake | `handshake-response.schema.json` | client |
| Busta | `envelope.schema.json` | server |
| Misura | `telemetry.schema.json` | client (prima di cifrare) e server (dopo aver decifrato) |
| Ack | `telemetry-ack.schema.json` | test |
| Richiesta misure | `readings-request.schema.json` | client e server |
| Elenco misure | `readings-response.schema.json` | test |
| Richiesta chiusura | `close-request.schema.json` | client e server |
| Conferma chiusura | `close-response.schema.json` | test |
| Errore | `error.schema.json` | test |

Parole chiave usate: `type`, `required`, `enum`, `const`, `minimum`/`maximum`, `pattern`, `format: date-time`, `minLength`, `additionalProperties: false`, `items`.

**Misura** (prima di essere cifrata):
```json
{ "sensor_id": "CELLA-BG-007", "timestamp": "2026-11-02T08:15:30Z", "cargo_type": "pharma",
  "temperature_c": 4.6, "humidity": 55, "battery": 87 }
```

**Ack con allarme**:
```json
{ "status": "ok", "sensor_id": "CELLA-BG-007", "received_at": "2026-11-02T08:15:31Z",
  "alarm": true, "alarm_message": "temperatura 11.4 C fuori intervallo 2..8 C (pharma)" }
```

**Richiesta misure**: `sensor_id` obbligatorio; `from` e `to` (date-time) facoltativi.
**Risposta**: `{ "sensor_id": "...", "count": 3, "readings": [ ... ] }`.

### Il file delle misure: `Server/data/readings.json`

Ogni misura accettata viene aggiunta a un elenco, e il server riscrive il file. Il file contiene la misura così come l'ha inviata il client, più due campi aggiunti dal server: `received_at` (ora di arrivo) e `alarm`.
Al riavvio il server ricarica il file. `/api/readings` legge da qui.

```json
[
  {
    "sensor_id": "CELLA-BG-001",
    "timestamp": "2026-11-09T08:04:31Z",
    "cargo_type": "pharma",
    "temperature_c": 5.1,
    "humidity": 52,
    "battery": 99,
    "received_at": "2026-11-09T08:04:31Z",
    "alarm": false
  }
]
```

### Allarmi

| `cargo_type` | Intervallo di sicurezza |
|---|---|
| `food` | 0 … 4 °C |
| `pharma` | 2 … 8 °C |
| `frozen` | −25 … −18 °C |

Fuori intervallo → `alarm: true` e `alarm_message`. Le soglie stanno in `SafeRange` (`Server/Program.cs`).

---

## Il client

**1) Tre sensori** in parallelo (`CELLA-BG-001` farmaci, `CAMION-MI-002` cibo, `CELLA-RM-003` surgelati), ognuno con la sua sessione:
handshake → 10 misure (ogni 4ª fuori intervallo, per far scattare l'allarme) → `/api/readings` → `/api/close`.
Ogni misura viene **validata con lo schema prima di essere cifrata**.

**2) Demo**: mostra la chiave calcolata, una misura valida e una non valida. Per ognuna stampa il JSON in chiaro, la busta che viaggia in rete e la risposta decifrata.
Lo schema blocca la misura non valida già nel client; poi la demo la invia lo stesso, senza validarla, per far vedere il 400 del server.

## Test (menu del client, voce 3, con il server acceso)

| # | Test |
|---|---|
| 1 | handshake riuscito: il server decifra un messaggio, quindi le chiavi coincidono |
| 2 | misura valida → 200, ack conforme allo schema |
| 3 | temperatura fuori intervallo → allarme |
| 4 | misura non valida → 400: `temperature_c` oltre il massimo, `cargo_type` fuori dall'enum, `timestamp` mancante; il client non la invia |
| 5 | busta manomessa → 400 e la misura non viene salvata |
| 6 | sessione inesistente → 404 |
| 7 | `/api/readings` restituisce le misure salvate, il filtro `from` funziona |
| 8 | `/api/close` → 200, poi la sessione dà 404 |
| 9 | handshake con `p` sbagliato → 400, rifiutato dallo schema (`const`) |
