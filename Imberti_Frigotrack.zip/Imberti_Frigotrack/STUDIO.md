# Guida allo studio – per l'interrogazione

Questo file non va consegnato: serve a capire il codice, a rispondere alle domande e a fare la modifica dal vivo.
La modifica dal vivo vale il 50% del voto e le domande il 25%: la cosa più importante è sapere **dove** mettere le mani.

## 1. Il progetto in 8 frasi (da saper dire a voce)

1. Sensore e server devono avere la stessa chiave segreta senza mandarla in rete: la ottengono con **Diffie-Hellman**.
2. Il client sceglie un segreto `a` e manda `A = g^a mod p`; il server sceglie `b` e risponde con `B = g^b mod p`.
3. Entrambi calcolano `K` (il client come `B^a mod p`, il server come `A^b mod p`): è lo stesso numero. Chi ascolta vede solo `A` e `B`.
4. La chiave AES-256 è `SHA-256(K)`, perché `K` è lungo 2048 bit e AES vuole 32 byte.
5. Ogni messaggio è un JSON, cifrato con **AES-GCM** e messo in una busta `{session_id, ciphertext, tag}`.
6. I messaggi sono validati con **JSON Schema** dalla libreria JsonSchema.Net: il client **valida e poi cifra**, il server **decifra e poi valida**.
7. Se la temperatura esce dall'intervallo del tipo di merce, la risposta contiene un allarme.
8. Il server **salva ogni misura** nel file `Server/data/readings.json` e la restituisce con `/api/readings`.

## 2. Ordine di lettura

| # | File | Cosa guardare | Righe |
|---|---|---|---|
| 1 | `Server/Crypto.cs` | `NewSecret`, `PublicKey`, `SharedKey` (Diffie-Hellman); `Encrypt`, `Decrypt`, `Seal` (AES-GCM e busta) | 138 |
| 2 | `schemas/telemetry.schema.json` | le regole di una misura: `type`, `required`, `enum`, `minimum`, `maximum`, `pattern`, `format`, `additionalProperties` | – |
| 3 | `Server/SchemaValidator.cs` | come si chiama la libreria: `FromFile`, `Evaluate`, poi `InstanceLocation` ed `Errors` | 79 |
| 4 | `Server/Program.cs` | dall'alto: `Main` → `HandleRequest` → `Handshake` / `EncryptedRequest` → `Telemetry` (salvataggio), `Readings`, `Close` → `Send` | 363 |
| 5 | `Client/Connection.cs` | `Handshake`, `Send` (valida → cifra → invia → decifra), `SendWithoutValidation`, `Post` | 86 |
| 6 | `Client/Program.cs` | menu, `RunSensor`, `Demo`, `NewMeasure` | 184 |
| 7 | `Client/Tests.cs` | un test alla volta: ognuno mostra un comportamento del server | 219 |

`Crypto.cs` e `SchemaValidator.cs` del Client sono **identici** a quelli del Server.

## 3. Come funziona la validazione (`SchemaValidator.cs`)

```
SchemaValidator.Validate(json, "telemetry")
  1  JsonSchema.FromFile(".../schemas/telemetry.schema.json")    la libreria legge lo schema
  2  JsonNode.Parse(json)                                         se non e' JSON -> errore
  3  schema.Evaluate(documento, opzioni)                          la libreria applica TUTTE le regole dello schema
        OutputFormat.List          = risultati in un unico elenco
        RequireFormatValidation    = controlla anche "format": "date-time"
        Culture "it"               = messaggi in italiano
  4  result.IsValid ?                                             si -> restituisce null (nessun errore)
  5  nel primo elemento con errori:
        InstanceLocation  "/temperature_c"   -> campo "temperature_c"
        Errors            {"maximum": "99 è maggiore di 40"}  -> messaggio
```

Nel codice non c'è nessun `if` sui campi: le regole stanno tutte negli schemi.
Per «manca un campo obbligatorio» l'errore riguarda l'oggetto intero, quindi `field` è vuoto e il messaggio nomina il campo: `Le proprietà richieste ["timestamp"] non sono presenti`.

## 4. Il percorso di una richiesta cifrata (`Server/Program.cs`)

```
Main               ciclo: GetContext() aspetta una richiesta, Task.Run la gestisce in parallelo
HandleRequest      POST? endpoint conosciuto?                                  no  -> 404
EncryptedRequest
   1  SchemaValidator.Validate(body, "envelope")                               errore -> 400 (in chiaro)
   2  sessions.TryGetValue(session_id)                                         no  -> 404 (in chiaro)
      DateTime.Now - session.LastUse > SessionTimeout                          si  -> 401 (in chiaro)
   3  Crypto.Decrypt(...)  (controlla il tag)                                  null -> 400 (in chiaro), nulla elaborato
   4  SchemaValidator.Validate(json, schemaName)                               errore -> 400 CIFRATO con il campo
   5  Telemetry / Readings / Close                                                 -> 200 CIFRATO
Telemetry          allarme -> readings.Add(misura) -> File.WriteAllText(data/readings.json)
```

Perché alcuni errori sono in chiaro: ai passi 1-3 non c'è una chiave valida (o non ci si può fidare del messaggio), quindi non si può cifrare. Dal passo 4 in poi sì.

## 5. Diffie-Hellman con numeri piccoli (da fare alla lavagna)

`p = 23`, `g = 5`, segreto del client `a = 6`, segreto del server `b = 15`.

| | Client | Server |
|---|---|---|
| calcola | `A = 5^6 mod 23 = 8` | `B = 5^15 mod 23 = 19` |
| invia | `A = 8` | `B = 19` |
| chiave | `K = 19^6 mod 23 = 2` | `K = 8^15 mod 23 = 2` |

Chi ascolta conosce `p, g, A, B`. Per trovare `a` o `b` dovrebbe risolvere il **logaritmo discreto**, impossibile con `p` da 2048 bit.
`BigInteger.ModPow(base, esponente, modulo)` calcola `base^esponente mod modulo` senza costruire il numero enorme `base^esponente`.

## 6. Modifiche dal vivo: dove mettere le mani

Dopo ogni modifica al codice, riavvia il **Server** (F5 nella sua finestra). Poi nel Client usa la voce `3` (test) e la voce `1` (sensori).
Le modifiche agli schemi valgono subito, anche senza riavviare, perché ogni validazione rilegge il file.

### a) Cambiare le soglie dell'allarme
`Server/Program.cs`, metodo `SafeRange`: cambia i numeri.

### b) Nuovo tipo di merce (es. `vaccine`, 2…8 °C)
1. `schemas/telemetry.schema.json`: aggiungi `"vaccine"` all'`enum` di `cargo_type`.
2. `schemas/readings-response.schema.json`: stessa cosa nell'`enum` dentro `items` (**è in due schemi**).
3. `Server/Program.cs`, `SafeRange`: aggiungi `case "vaccine": min = 2; max = 8; break;`
4. Per provarlo, `Client/Program.cs`, `StartSensors`: aggiungi
   `Task t4 = Task.Run(() => RunSensor("CELLA-MI-004", "vaccine", 5));` e scrivi `Task.WaitAll(t1, t2, t3, t4);`

### c) Nuovo campo nella misura (es. `door_open`, vero/falso, facoltativo)
1. `schemas/telemetry.schema.json`, dentro `properties`: `"door_open": { "type": "boolean" }`
2. `schemas/readings-response.schema.json`, dentro `items` → `properties`: la stessa riga.
   Se la dimentichi, il test 7 fallisce: il server salva e restituisce la misura con il campo nuovo, ma lo schema della risposta (`additionalProperties: false`) non lo prevede.
3. `Client/Program.cs`, `NewMeasure`: aggiungi `measure["door_open"] = false;`
4. Il server non va toccato: salva in `readings.json` tutti i campi che riceve.

### d) Nuova regola su un campo (nessun codice da toccare)
La libreria conosce già tutte le parole chiave di JSON Schema: basta scriverle nello schema. Esempi in `telemetry.schema.json`:
- campo obbligatorio: aggiungi il nome in `required`;
- limiti diversi: cambia `minimum` / `maximum` (anche in `readings-response`, dentro `items`);
- `"sensor_id": { ..., "maxLength": 12 }`;
- `"battery": { ..., "multipleOf": 5 }` (solo multipli di 5);
- `"temperature_c": { ..., "exclusiveMaximum": 40 }` (40 escluso).

### e) Nuovo allarme (es. umidità sopra 80%)
`Server/Program.cs`, metodo `Telemetry`. Subito **prima** della riga `bool alarm = alarmMessage != "";` aggiungi:
```csharp
if (measure["humidity"] != null && (double)measure["humidity"] > 80)
    alarmMessage = "umidita " + measure["humidity"] + "% sopra il limite del 80%";
```
Il controllo `!= null` serve perché `humidity` è facoltativo. Se scattano due allarmi resta l'ultimo messaggio; per averli entrambi usa `alarmMessage += " - " + ...`.
Per vederlo scattare abbassa la soglia a 60: i sensori simulati generano umidità tra 40 e 69.

### f) Nuovo endpoint (es. `/api/stats`: minimo, massimo e media di un sensore)
1. Crea `schemas/stats-request.schema.json` copiando `readings-request.schema.json` e lasciando solo `sensor_id`.
2. `Server/Program.cs`, `HandleRequest`: aggiungi `|| path == "/api/stats"` alla condizione con gli altri tre endpoint.
3. `EncryptedRequest`, passo 4: `if (path == "/api/stats") schemaName = "stats-request";`
4. `EncryptedRequest`, passo 5: `if (path == "/api/stats") Stats(context, session, message);`
5. Scrivi il metodo copiando `Readings`:
```csharp
static void Stats(HttpListenerContext context, Session session, JsonObject request)
{
    string sensorId = (string)request["sensor_id"];

    List<double> temperatures = new List<double>();
    lock (locker)
    {
        foreach (JsonNode reading in readings)
        {
            if ((string)reading["sensor_id"] == sensorId)
                temperatures.Add((double)reading["temperature_c"]);
        }
    }

    JsonObject response = new JsonObject();
    response["sensor_id"] = sensorId;
    response["count"] = temperatures.Count;
    if (temperatures.Count > 0)
    {
        response["min"] = temperatures.Min();
        response["max"] = temperatures.Max();
        response["avg"] = Math.Round(temperatures.Average(), 1);
    }
    SendEncrypted(context, 200, session, response.ToJsonString());
}
```
6. Nel client: `connection.Send("/api/stats", request.ToJsonString(), "stats-request", out int status);`, con `request` costruito come in `RunSensor` per `/api/readings`.
7. Per completezza, scrivi anche `stats-response.schema.json`.

### g) Scadenza della sessione (per far vedere il 401)
`Server/Program.cs`: `TimeSpan.FromMinutes(10)` → `TimeSpan.FromSeconds(2)`.
`Client/Program.cs`: `IntervalMs = 3000` e `MeasuresPerSensor = 2`. Alla seconda misura ogni sensore riceve 401 e si ferma.

### h) Cambiare porta
`Url` in `Server/Program.cs` **e** in `Client/Program.cs` (es. 6000 in entrambi).

### i) Chiave AES-128 invece di AES-256
In **entrambi** i `Crypto.cs`, metodo `SharedKey`:
`return SHA256.HashData(K.ToByteArray()).Take(16).ToArray();`
Se lo cambi in uno solo, client e server hanno chiavi diverse e ogni messaggio riceve 400.

### j) Protezione dal replay (una busta ripetuta viene rifiutata)
Ogni busta ha un tag diverso, perché il nonce è casuale. Il server ricorda i tag già visti in quella sessione.
1. `Server/Program.cs`, classe `Session`: `public HashSet<string> SeenTags = new HashSet<string>();`
2. `EncryptedRequest`, subito dopo `session.LastUse = DateTime.Now;`:
```csharp
bool isNew;
lock (locker)
{
    isNew = session.SeenTags.Add((string)envelope["tag"]);
}
if (!isNew)
{
    SendEncrypted(context, 400, session, ErrorJson("busta gia ricevuta (replay)", ""));
    return;
}
```
`HashSet.Add` restituisce `false` se l'elemento c'era già.

### k) Cambiare il formato dell'identificativo del sensore
La regex `^[A-Z]+-[A-Z]{2}-[0-9]{3}$` compare **5 volte**: in `telemetry`, `telemetry-ack`, `readings-request` e 2 volte in `readings-response`.
Usa *Modifica → Trova e sostituisci → Cerca nei file*.

### l) Cambiare un codice HTTP
- Sessione inesistente: `EncryptedRequest`, passo 2, `Send(context, 404, ...)`.
- Metodo diverso da POST: in `HandleRequest` (per esempio 405 invece di 404).
- Se cambi un codice, aggiorna anche il test corrispondente in `Client/Tests.cs`.

### m) Sensori, numero di misure, frequenza
`Client/Program.cs`: `StartSensors` (identificativo, merce, temperatura normale), `MeasuresPerSensor`, `IntervalMs`.
Per far scattare l'allarme più o meno spesso: `if (n % 4 == 0)` in `RunSensor`.

### n) Salvare un dato in più nel file (es. il `session_id`)
`Server/Program.cs`, metodo `Telemetry`, accanto a `measure["received_at"] = now;` aggiungi `measure["session_id"] = session.Id;`.
Poi aggiungi `"session_id": { "type": "string" }` dentro `items` → `properties` di `readings-response.schema.json`, altrimenti il test 7 fallisce.

## 7. Domande probabili e risposte brevi

**Chi controlla che un messaggio sia valido?** La libreria JsonSchema.Net, usando i file di `schemas/`. Il codice chiama solo `SchemaValidator.Validate` e, se c'è un errore, risponde 400 con il campo e il motivo che restituisce la libreria.

**Perché una libreria e non dei controlli scritti a mano?** Perché così le regole stanno solo negli schemi, che sono standard (draft 2020-12) e leggibili anche da altri programmi. Per cambiare una regola si cambia lo schema, non il codice.

**Come fa lo schema a controllare `p`?** Con `const`: il valore deve essere esattamente quel testo esadecimale, il `p` del gruppo 14. `g` deve essere `"2"`. Il `pattern` di `A` impone da 2 a 512 cifre esadecimali senza zeri iniziali, quindi `A` non può valere 0 o 1.

**C'è ancora un controllo nel codice?** Solo uno: `A < p-1`. È un confronto tra numeri da 2048 bit, che JSON Schema non sa fare su un testo esadecimale.

**Dove e come salva le misure il server?** In `Server/data/readings.json`. A ogni misura accettata aggiunge la misura all'elenco `readings`, con `received_at` e `alarm`, e riscrive tutto il file dentro un `lock`. All'avvio ricarica il file.

**Perché Diffie-Hellman e non mandare la chiave?** Perché in rete passa tutto in chiaro: chi ascolta vedrebbe la chiave. Con DH passano solo `A` e `B`, e da questi ricavare `K` richiede il logaritmo discreto.

**Perché SHA-256 di K?** `K` è un numero da 2048 bit, ma AES-256 vuole 32 byte. L'hash lo riduce a 32 byte e ne mescola i bit.

**Cos'è il tag di GCM?** Una "firma" del messaggio calcolata con la chiave. Se qualcuno cambia anche un solo bit, il tag non torna e la decifratura fallisce: il test 5 lo dimostra.

**Perché un nonce nuovo per ogni messaggio?** Con la stessa chiave, ripetere il nonce in GCM permette di ricavare informazioni sui messaggi e di falsificarli. Qui sono 12 byte casuali che viaggiano davanti al testo cifrato: il nonce non è un segreto.

**Perché il server decifra e poi valida?** Prima della decifratura il contenuto è illeggibile, quindi non si può validare. E non si deve elaborare niente che non abbia superato il controllo del tag.

**Se il server valida comunque, perché valida anche il client?** Per non spedire dati sbagliati e scoprire l'errore subito. Il server però non si fida mai del client.

**Cosa viaggia in chiaro?** `session_id`, gli indirizzi degli endpoint, i numeri `p, g, A, B` dell'handshake e gli errori che arrivano prima della decifratura.

**Come gestisce più client insieme?** `GetContext()` riceve una richiesta e `Task.Run` la affida a un altro thread, poi il ciclo torna subito ad aspettare. Ogni client ha la sua `Session` nel dizionario. Dizionario e lista delle misure sono condivisi, quindi ogni accesso è dentro `lock(locker)`.

**A cosa serve `lock`?** Fa entrare un thread alla volta nel blocco. Senza, due misure salvate nello stesso momento potrebbero rovinare la lista o il file.

**Cosa succede se qualcuno reinvia una busta catturata?** Oggi viene accettata (limite noto: replay). Per risolverlo vedi la ricetta **j**.

**E se qualcuno si mette in mezzo durante l'handshake?** DH non verifica con chi stai parlando: un attaccante attivo può fare due handshake e leggere tutto (man-in-the-middle). Servirebbe una firma o una chiave pre-condivisa.

**Perché i numeri grandi sono testo esadecimale?** Molti programmi leggono i numeri JSON come `double`, che perde precisione dopo circa 15 cifre; `p` ne ha più di 600.

**Differenza tra `required` e `additionalProperties: false`?** `required` elenca i campi che devono esserci; `additionalProperties: false` vieta i campi non elencati in `properties`.

**Perché `Crypto.cs` e `SchemaValidator.cs` sono uguali nei due progetti?** Client e server devono fare esattamente gli stessi calcoli e la stessa validazione. Dato che i progetti sono separati, i file sono copiati in entrambi.

## 8. Prove da fare prima dell'interrogazione

1. Avvia server e client, voce `2` del menu, e leggi riga per riga cosa viaggia in rete.
2. Apri `Server/data/readings.json` dopo la voce `1` e riconosci ogni campo.
3. Aggiungi `"humidity"` a `required` in `telemetry.schema.json`, poi togli `measure["humidity"] = humidity;` da `NewMeasure`: guarda l'errore che dà lo schema.
4. Metti `"maximum": 30` su `temperature_c` e guarda il messaggio della libreria.
5. Prova la ricetta **g** e guarda comparire il 401.
6. Scrivi un test nuovo in `Client/Tests.cs` copiando `UnknownSession` e aggiungilo in `RunAll`.

## 9. Git

Durante l'interrogazione il docente guarda la cronologia dei commit. Fai commit piccoli e **veri**: uno per ogni cosa che provi o modifichi davvero mentre studi, con un messaggio che lo descrive (per esempio «Aggiunto tipo di merce vaccine»).

```bash
git init
git add .
git commit -m "Struttura iniziale: server, client, schemi"
```
