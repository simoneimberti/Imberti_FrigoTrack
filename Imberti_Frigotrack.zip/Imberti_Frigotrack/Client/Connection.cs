using System.Numerics;
using System.Text;
using System.Text.Json.Nodes;

/// <summary>
/// Il collegamento cifrato con il server: prima l'handshake, poi i messaggi nella busta.
/// Ogni sensore crea la sua Connection, quindi ha la sua sessione e la sua chiave.
/// </summary>
class Connection
{
    static readonly HttpClient http = new HttpClient();   // uno solo per tutto il programma

    public string SessionId = "";
    public byte[] Key = new byte[32];
    public bool ShowTraffic = false;   // se true stampa cio' che viaggia davvero in rete (usato dalla demo)

    // ---------------- Handshake Diffie-Hellman: va fatto prima di inviare qualsiasi dato ----------------
    public void Handshake()
    {
        BigInteger a = Crypto.NewSecret();     // segreto del client: non esce mai da qui
        BigInteger A = Crypto.PublicKey(a);    // A = g^a mod p

        JsonObject request = new JsonObject();
        request["p"] = Crypto.ToHex(Crypto.P);
        request["g"] = Crypto.ToHex(Crypto.G);
        request["A"] = Crypto.ToHex(A);

        string answer = Post("/api/handshake", request.ToJsonString(), out int status);
        if (status != 200)
            throw new Exception("handshake rifiutato (HTTP " + status + "): " + answer);

        SchemaError error = SchemaValidator.Validate(answer, "handshake-response");
        if (error != null)
            throw new Exception("risposta dell'handshake non valida: campo '" + error.Field + "' " + error.Message);

        JsonNode response = JsonNode.Parse(answer);
        BigInteger B = Crypto.FromHex((string)response["B"]);
        SessionId = (string)response["session_id"];
        Key = Crypto.SharedKey(B, a);          // K = B^a mod p  ->  chiave AES
    }

    // ---------------- Invio normale: valida con lo schema, POI cifra e invia ----------------
    public JsonNode Send(string path, string json, string schemaName, out int status)
    {
        SchemaError error = SchemaValidator.Validate(json, schemaName);
        if (error != null)
            throw new Exception("il client non invia il messaggio: campo '" + error.Field + "' " + error.Message);

        return SendWithoutValidation(path, json, out status);
    }

    // ---------------- Cifra e invia SENZA validare ----------------
    // Serve solo alla demo e ai test, per far arrivare al server un messaggio sbagliato e vedere il suo 400.
    public JsonNode SendWithoutValidation(string path, string json, out int status)
    {
        string envelope = Crypto.Seal(SessionId, Key, json);
        if (ShowTraffic) Console.WriteLine("   in rete  -> " + envelope);

        string answer = Post(path, envelope, out status);
        if (ShowTraffic) Console.WriteLine("   in rete  <- HTTP " + status + " " + answer);

        return OpenAnswer(answer);
    }

    // La risposta e' una busta cifrata da aprire, oppure un errore in chiaro (es. sessione inesistente)
    public JsonNode OpenAnswer(string answer)
    {
        JsonNode node = JsonNode.Parse(answer);
        if (node["ciphertext"] == null) return node;   // errore in chiaro: niente da decifrare

        string json = Crypto.Decrypt(Key, (string)node["ciphertext"], (string)node["tag"]);
        if (json == null) throw new Exception("la risposta del server non si decifra (manomessa?)");
        return JsonNode.Parse(json);
    }

    // POST di un testo JSON al server. Restituisce il corpo della risposta e il codice HTTP.
    public string Post(string path, string body, out int status)
    {
        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, Program.Url + path);
        request.Content = new StringContent(body, Encoding.UTF8, "application/json");

        HttpResponseMessage response = http.Send(request);
        status = (int)response.StatusCode;
        return new StreamReader(response.Content.ReadAsStream()).ReadToEnd();
    }
}
