using System.Globalization;
using System.Net.Http;
using System.Text.Json.Nodes;

class Program
{
    // Indirizzo del server. Se lo cambi, cambialo anche nel Server (Server/Program.cs).
    public const string Url = "http://localhost:5000";

    // Quante misure invia ogni sensore e ogni quanti millisecondi
    const int MeasuresPerSensor = 10;
    const int IntervalMs = 2000;

    static void Main()
    {
        // punto decimale sempre con il punto (anche se Windows e' in italiano)
        CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
        CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

        if (!Directory.Exists(SchemaValidator.SchemasFolder))
            Console.WriteLine("ATTENZIONE: cartella degli schemi non trovata: " + SchemaValidator.SchemasFolder);

        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("===== FrigoTrack - client dei sensori (server: " + Url + ") =====");
            Console.WriteLine("1) Avvia i 3 sensori (" + MeasuresPerSensor + " misure ciascuno, una ogni " + IntervalMs / 1000 + " secondi)");
            Console.WriteLine("2) Demo: una misura valida e una non valida, mostrando cosa viaggia in rete");
            Console.WriteLine("3) Esegui i test (il server deve essere acceso)");
            Console.WriteLine("0) Esci");
            Console.Write("Scelta: ");

            string choice = Console.ReadLine();
            if (choice == null || choice == "0") return;

            if (choice == "1") StartSensors();
            else if (choice == "2") Demo();
            else if (choice == "3") Tests.RunAll();
            else Console.WriteLine("Scelta non valida");
        }
    }

    // ===================================================================
    //  1) Tre sensori che lavorano in parallelo, ognuno con la sua sessione
    // ===================================================================
    static void StartSensors()
    {
        // identificativo, tipo di merce, temperatura "normale" del sensore
        Task t1 = Task.Run(() => RunSensor("CELLA-BG-001", "pharma", 5));
        Task t2 = Task.Run(() => RunSensor("CAMION-MI-002", "food", 2));
        Task t3 = Task.Run(() => RunSensor("CELLA-RM-003", "frozen", -20));
        Task.WaitAll(t1, t2, t3);
        Console.WriteLine("Tutti i sensori hanno finito.");
    }

    static void RunSensor(string sensorId, string cargo, double normalTemperature)
    {
        try
        {
            Connection connection = new Connection();
            connection.Handshake();
            Log(sensorId, "handshake fatto, sessione " + connection.SessionId);

            Random random = new Random();
            for (int n = 1; n <= MeasuresPerSensor; n++)
            {
                // temperatura normale +/- 0,5 gradi; ogni 4 misure una fuori intervallo (allarme)
                double temperature = normalTemperature + random.NextDouble() - 0.5;
                if (n % 4 == 0) temperature = temperature + 6;
                temperature = Math.Round(temperature, 1);

                JsonObject measure = NewMeasure(sensorId, cargo, temperature, random.Next(40, 70), 100 - n);
                JsonNode ack = connection.Send("/api/telemetry", measure.ToJsonString(), "telemetry", out int status);

                if (status != 200)
                {
                    // per esempio 401 (sessione scaduta) o 404 (sessione inesistente): il sensore si ferma
                    Log(sensorId, "misura " + n + ": " + temperature + " C -> HTTP " + status + " " + ack["error"] + ". Il sensore si ferma.");
                    return;
                }

                if ((bool)ack["alarm"])
                    Log(sensorId, "misura " + n + ": " + temperature + " C -> ALLARME: " + ack["alarm_message"]);
                else
                    Log(sensorId, "misura " + n + ": " + temperature + " C -> ok");

                Thread.Sleep(IntervalMs);
            }

            // chiedo al server le misure che ha salvato per questo sensore
            JsonObject request = new JsonObject();
            request["sensor_id"] = sensorId;
            JsonNode list = connection.Send("/api/readings", request.ToJsonString(), "readings-request", out int status2);
            Log(sensorId, "/api/readings -> HTTP " + status2 + ", il server ha salvato " + list["count"] + " misure di questo sensore");

            // chiudo la sessione: il server cancella la chiave
            JsonObject close = new JsonObject();
            close["action"] = "close";
            connection.Send("/api/close", close.ToJsonString(), "close-request", out int status3);
            Log(sensorId, "/api/close -> HTTP " + status3 + ", sessione chiusa");
        }
        catch (HttpRequestException)
        {
            Log(sensorId, "ERRORE: server non raggiungibile su " + Url + ". Hai avviato il Server?");
        }
        catch (Exception ex)
        {
            Log(sensorId, "ERRORE: " + ex.Message);
        }
    }

    // ===================================================================
    //  2) Demo per l'interrogazione: misura valida e misura non valida
    // ===================================================================
    static void Demo()
    {
        try
        {
            Connection connection = new Connection();
            connection.ShowTraffic = true;

            Console.WriteLine();
            Console.WriteLine("--- Handshake ---");
            connection.Handshake();
            Console.WriteLine("   session_id = " + connection.SessionId);
            Console.WriteLine("   chiave AES calcolata (NON viaggia in rete): " + Convert.ToHexString(connection.Key));

            Console.WriteLine();
            Console.WriteLine("--- Misura VALIDA ---");
            JsonObject good = NewMeasure("CELLA-BG-007", "pharma", 4.6, 55, 87);
            Console.WriteLine("   in chiaro (solo qui)  " + good.ToJsonString());
            JsonNode ack = connection.Send("/api/telemetry", good.ToJsonString(), "telemetry", out int status);
            Console.WriteLine("   risposta decifrata: HTTP " + status + " " + ack.ToJsonString());

            Console.WriteLine();
            Console.WriteLine("--- Misura NON VALIDA (99 gradi, il massimo e' 40) ---");
            JsonObject bad = NewMeasure("CELLA-BG-007", "pharma", 99, 55, 87);
            Console.WriteLine("   in chiaro (solo qui)  " + bad.ToJsonString());

            SchemaError error = SchemaValidator.Validate(bad.ToJsonString(), "telemetry");
            Console.WriteLine("   lo schema la rifiuta gia' nel client: campo '" + error.Field + "' -> " + error.Message);
            Console.WriteLine("   la invio lo stesso, senza validarla, per vedere cosa risponde il server:");
            JsonNode answer = connection.SendWithoutValidation("/api/telemetry", bad.ToJsonString(), out status);
            Console.WriteLine("   risposta decifrata: HTTP " + status + "  errore: " + answer["error"] + "  campo: " + answer["field"]);

            connection.ShowTraffic = false;
            JsonObject close = new JsonObject();
            close["action"] = "close";
            connection.Send("/api/close", close.ToJsonString(), "close-request", out status);
            Console.WriteLine();
            Console.WriteLine("Sessione chiusa (HTTP " + status + ").");
        }
        catch (HttpRequestException)
        {
            Console.WriteLine("ERRORE: server non raggiungibile su " + Url + ". Hai avviato il Server?");
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERRORE: " + ex.Message);
        }
    }

    // ===================================================================
    //  Funzioni di supporto
    // ===================================================================

    // Crea il messaggio di una misura (lo stesso formato dell'esempio della consegna)
    public static JsonObject NewMeasure(string sensorId, string cargo, double temperature, int humidity, int battery)
    {
        JsonObject measure = new JsonObject();
        measure["sensor_id"] = sensorId;
        measure["timestamp"] = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'");
        measure["cargo_type"] = cargo;
        measure["temperature_c"] = temperature;
        measure["humidity"] = humidity;
        measure["battery"] = battery;
        return measure;
    }

    static void Log(string sensorId, string text)
    {
        Console.WriteLine("[" + DateTime.Now.ToString("HH:mm:ss") + "] [" + sensorId + "] " + text);
    }
}
