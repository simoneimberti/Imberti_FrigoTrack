using System.Globalization;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;

// ATTENZIONE: questo file e' IDENTICO nel Server e nel Client.
// Se lo modifichi, copia la stessa modifica anche nell'altro progetto.

/// <summary>
/// Diffie-Hellman (scritto a mano) e cifratura AES-GCM.
///
/// Diffie-Hellman:
///   client: segreto a  ->  A = g^a mod p  ->  invia A
///   server: segreto b  ->  B = g^b mod p  ->  invia B
///   client: K = B^a mod p        server: K = A^b mod p     (e' lo stesso numero)
/// a, b e K non viaggiano mai in rete.
/// </summary>
static class Crypto
{
    // Gruppo 14 dell'RFC 3526: numero primo p da 2048 bit e generatore g = 2
    public static readonly BigInteger P = FromHex(
        "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
        "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
        "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
        "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
        "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D" +
        "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F" +
        "83655D23DCA3AD961C62F356208552BB9ED529077096966D" +
        "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
        "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9" +
        "DE2BCBF6955817183995497CEA956AE515D2261898FA0510" +
        "15728E5A8AACAA68FFFFFFFFFFFFFFFF");

    public static readonly BigInteger G = 2;

    // ------------------------- Diffie-Hellman -------------------------

    // Segreto casuale (a per il client, b per il server): 32 byte casuali = 256 bit
    public static BigInteger NewSecret()
    {
        byte[] bytes = RandomNumberGenerator.GetBytes(32);
        return new BigInteger(bytes, isUnsigned: true);
    }

    // Chiave pubblica: A = g^a mod p   (oppure B = g^b mod p)
    public static BigInteger PublicKey(BigInteger secret)
    {
        return BigInteger.ModPow(G, secret, P);
    }

    // Chiave condivisa. K e' un numero da 2048 bit, ma AES-256 vuole 32 byte:
    // per questo la chiave AES e' SHA-256(K).
    public static byte[] SharedKey(BigInteger otherPublicKey, BigInteger mySecret)
    {
        BigInteger K = BigInteger.ModPow(otherPublicKey, mySecret, P);   // K = B^a mod p  (= A^b mod p)
        return SHA256.HashData(K.ToByteArray());
    }

    // I numeri grandi viaggiano in JSON come testo esadecimale
    // ToString("X") a volte aggiunge uno 0 davanti: lo tolgo, cosi' p e' scritto sempre
    // allo stesso modo (lo schema handshake-request lo confronta con "const")
    public static string ToHex(BigInteger number)
    {
        return number.ToString("X").TrimStart('0');
    }

    public static BigInteger FromHex(string hex)
    {
        // lo "0" davanti serve perche' BigInteger non legga il numero come negativo
        return BigInteger.Parse("0" + hex, NumberStyles.HexNumber);
    }

    // ------------------------- AES-GCM -------------------------

    // Cifra un testo. Il nonce (12 byte casuali, nuovo per ogni messaggio) viene messo
    // davanti al testo cifrato. Il tag (16 byte) serve a scoprire le manomissioni.
    public static void Encrypt(byte[] key, string text, out string ciphertext, out string tag)
    {
        byte[] plain = Encoding.UTF8.GetBytes(text);
        byte[] nonce = RandomNumberGenerator.GetBytes(12);
        byte[] cipher = new byte[plain.Length];
        byte[] tagBytes = new byte[16];

        using (AesGcm aes = new AesGcm(key, 16))
        {
            aes.Encrypt(nonce, plain, cipher, tagBytes);
        }

        ciphertext = Convert.ToBase64String(nonce.Concat(cipher).ToArray());
        tag = Convert.ToBase64String(tagBytes);
    }

    // Decifra. Restituisce null se il messaggio e' stato manomesso (il tag non torna),
    // se la chiave e' sbagliata o se il Base64 non e' valido.
    public static string Decrypt(byte[] key, string ciphertext, string tag)
    {
        try
        {
            byte[] data = Convert.FromBase64String(ciphertext);
            byte[] tagBytes = Convert.FromBase64String(tag);

            byte[] nonce = data.Take(12).ToArray();     // i primi 12 byte sono il nonce
            byte[] cipher = data.Skip(12).ToArray();    // il resto e' il testo cifrato
            byte[] plain = new byte[cipher.Length];

            using (AesGcm aes = new AesGcm(key, 16))
            {
                aes.Decrypt(nonce, cipher, tagBytes, plain);   // se il tag non torna lancia un'eccezione
            }
            return Encoding.UTF8.GetString(plain);
        }
        catch
        {
            return null;
        }
    }

    // Mette un JSON in una busta: {"session_id": "...", "ciphertext": "...", "tag": "..."}
    public static string Seal(string sessionId, byte[] key, string json)
    {
        Encrypt(key, json, out string ciphertext, out string tag);

        JsonObject envelope = new JsonObject();
        envelope["session_id"] = sessionId;
        envelope["ciphertext"] = ciphertext;
        envelope["tag"] = tag;
        return envelope.ToJsonString(Readable);
    }

    // Opzioni per scrivere il JSON senza trasformare + ' e lettere accentate in \u002B, \u0027...
    public static readonly JsonSerializerOptions Readable = new JsonSerializerOptions
    {
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };
}
