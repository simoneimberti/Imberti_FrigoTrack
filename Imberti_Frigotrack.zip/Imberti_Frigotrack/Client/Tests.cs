using System.Text.Json.Nodes;

/// <summary>
/// Test automatici. Il server deve essere acceso.
/// Ogni test e' una funzione: se una condizione non e' vera lancia un'eccezione e il test FALLISCE.
/// </summary>
static class Tests
{
    static int passed = 0;
    static int failed = 0;

    public static void RunAll()
    {
        passed = 0;
        failed = 0;
        Console.WriteLine();

        Run("1. Handshake riuscito (stessa chiave su client e server)", HandshakeOk);
        Run("2. Misura valida -> 200 e conferma", ValidMeasure);
        Run("3. Temperatura fuori intervallo -> allarme", Alarm);
        Run("4. Misura non valida -> 400 con il campo sbagliato", InvalidMeasure);
        Run("5. Busta manomessa -> 400 e nulla viene salvato", TamperedEnvelope);
        Run("6. Sessione inesistente -> 404", UnknownSession);
        Run("7. /api/readings restituisce le misure salvate", ReadingsList);
        Run("8. /api/close chiude la sessione (poi 404)", CloseSession);
        Run("9. Handshake con p sbagliato -> 400 (lo controlla lo schema con const)", WrongGroup);

        Console.WriteLine();
        Console.WriteLine("Risultato: " + passed + " passati, " + failed + " falliti");
    }

    // Esegue un test e stampa OK o FALLITO
    static void Run(string name, Action test)
    {
        try
        {
            test();
            passed++;
            Console.WriteLine("[OK]       " + name);
        }
        catch (Exception ex)
        {
            failed++;
            Console.WriteLine("[FALLITO]  " + name + "  ->  " + ex.Message);
        }
    }

    // Se la condizione e' falsa il test fallisce con questo messaggio
    static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }

    // Controlla che un messaggio rispetti il suo schema
    static void CheckSchema(JsonNode message, string schemaName)
    {
        SchemaError error = SchemaValidator.Validate(message.ToJsonString(), schemaName);
        Check(error == null, "la risposta non rispetta " + schemaName + ".schema.json: " + (error == null ? "" : error.Field + " " + error.Message));
    }

    // ===================================================================

    static void HandshakeOk()
    {
        Connection connection = new Connection();
        connection.Handshake();
        Check(connection.SessionId.Length == 16, "session_id mancante");

        // se le due chiavi fossero diverse il server non riuscirebbe a decifrare e risponderebbe 400
        JsonObject measure = Program.NewMeasure("CELLA-BG-001", "pharma", 5, 50, 90);
        connection.Send("/api/telemetry", measure.ToJsonString(), "telemetry", out int status);
        Check(status == 200, "atteso 200, ricevuto " + status);
    }

    static void ValidMeasure()
    {
        Connection connection = new Connection();
        connection.Handshake();

        JsonObject measure = Program.NewMeasure("CELLA-BG-002", "pharma", 4.6, 55, 87);
        JsonNode ack = connection.Send("/api/telemetry", measure.ToJsonString(), "telemetry", out int status);

        Check(status == 200, "atteso 200, ricevuto " + status);
        Check((string)ack["status"] == "ok", "status diverso da ok");
        Check((bool)ack["alarm"] == false, "allarme non previsto");
        CheckSchema(ack, "telemetry-ack");
    }

    static void Alarm()
    {
        Connection connection = new Connection();
        connection.Handshake();

        // farmaci a 12 gradi: fuori dall'intervallo 2..8
        JsonObject measure = Program.NewMeasure("CELLA-BG-003", "pharma", 12, 55, 87);
        JsonNode ack = connection.Send("/api/telemetry", measure.ToJsonString(), "telemetry", out int status);

        Check(status == 200, "atteso 200, ricevuto " + status);
        Check((bool)ack["alarm"] == true, "l'allarme non e' scattato");
        Check(ack["alarm_message"] != null, "manca alarm_message");
    }

    static void InvalidMeasure()
    {
        Connection connection = new Connection();
        connection.Handshake();

        // temperatura 99: oltre il massimo (40). La invio senza validarla nel client.
        JsonObject hot = Program.NewMeasure("CELLA-BG-004", "pharma", 99, 55, 87);
        JsonNode error = connection.SendWithoutValidation("/api/telemetry", hot.ToJsonString(), out int status);
        Check(status == 400, "atteso 400, ricevuto " + status);
        Check((string)error["field"] == "temperature_c", "campo indicato: " + error["field"]);
        CheckSchema(error, "error");

        // tipo di merce che non esiste
        JsonObject wrongCargo = Program.NewMeasure("CELLA-BG-004", "gelato", 3, 55, 87);
        error = connection.SendWithoutValidation("/api/telemetry", wrongCargo.ToJsonString(), out status);
        Check(status == 400, "atteso 400, ricevuto " + status);
        Check((string)error["field"] == "cargo_type", "campo indicato: " + error["field"]);

        // manca un campo obbligatorio (required): il messaggio d'errore lo nomina
        JsonObject incomplete = Program.NewMeasure("CELLA-BG-004", "pharma", 5, 55, 87);
        incomplete.Remove("timestamp");
        error = connection.SendWithoutValidation("/api/telemetry", incomplete.ToJsonString(), out status);
        Check(status == 400, "atteso 400, ricevuto " + status);
        Check(((string)error["error"]).Contains("timestamp"), "l'errore non nomina il campo mancante: " + error["error"]);

        // il client, invece, non la invia nemmeno
        bool blocked = false;
        try { connection.Send("/api/telemetry", hot.ToJsonString(), "telemetry", out status); }
        catch (Exception) { blocked = true; }
        Check(blocked, "il client ha inviato una misura non valida");
    }

    static void TamperedEnvelope()
    {
        Connection connection = new Connection();
        connection.Handshake();

        // busta corretta, poi cambio un bit del testo cifrato (come farebbe un attaccante)
        JsonObject measure = Program.NewMeasure("FALSO-XX-001", "pharma", 5, 55, 87);
        JsonNode envelope = JsonNode.Parse(Crypto.Seal(connection.SessionId, connection.Key, measure.ToJsonString()));
        byte[] data = Convert.FromBase64String((string)envelope["ciphertext"]);
        data[data.Length - 1] = (byte)(data[data.Length - 1] ^ 1);
        envelope["ciphertext"] = Convert.ToBase64String(data);

        connection.Post("/api/telemetry", envelope.ToJsonString(), out int status);
        Check(status == 400, "atteso 400, ricevuto " + status);

        // il server non deve averla salvata
        JsonObject request = new JsonObject();
        request["sensor_id"] = "FALSO-XX-001";
        JsonNode list = connection.Send("/api/readings", request.ToJsonString(), "readings-request", out status);
        Check((int)list["count"] == 0, "la misura manomessa e' stata salvata");
    }

    static void UnknownSession()
    {
        Connection connection = new Connection();
        connection.SessionId = "0000000000000000";   // il server non l'ha mai creata (nessun handshake)

        JsonObject measure = Program.NewMeasure("CELLA-BG-006", "pharma", 5, 55, 87);
        JsonNode error = connection.Send("/api/telemetry", measure.ToJsonString(), "telemetry", out int status);
        Check(status == 404, "atteso 404, ricevuto " + status);
        CheckSchema(error, "error");
    }

    static void ReadingsList()
    {
        Connection connection = new Connection();
        connection.Handshake();

        JsonObject measure = Program.NewMeasure("CELLA-BG-007", "food", 3, 55, 87);
        connection.Send("/api/telemetry", measure.ToJsonString(), "telemetry", out int status);

        JsonObject request = new JsonObject();
        request["sensor_id"] = "CELLA-BG-007";
        JsonNode list = connection.Send("/api/readings", request.ToJsonString(), "readings-request", out status);
        Check(status == 200, "atteso 200, ricevuto " + status);
        Check((int)list["count"] >= 1, "nessuna misura restituita");
        CheckSchema(list, "readings-response");

        // con un intervallo nel futuro non c'e' nessuna misura
        request["from"] = "2099-01-01T00:00:00Z";
        list = connection.Send("/api/readings", request.ToJsonString(), "readings-request", out status);
        Check((int)list["count"] == 0, "il filtro 'from' non funziona");
    }

    static void WrongGroup()
    {
        // handshake con un p piccolo (23): lo schema handshake-request accetta solo il p del gruppo 14
        Connection connection = new Connection();
        JsonObject request = new JsonObject();
        request["p"] = "17";
        request["g"] = "2";
        request["A"] = "1F";
        string answer = connection.Post("/api/handshake", request.ToJsonString(), out int status);

        Check(status == 400, "atteso 400, ricevuto " + status);
        Check((string)JsonNode.Parse(answer)["field"] == "p", "campo indicato: " + answer);
    }

    static void CloseSession()
    {
        Connection connection = new Connection();
        connection.Handshake();

        JsonObject close = new JsonObject();
        close["action"] = "close";
        JsonNode reply = connection.Send("/api/close", close.ToJsonString(), "close-request", out int status);
        Check(status == 200, "atteso 200, ricevuto " + status);
        CheckSchema(reply, "close-response");

        // dopo la chiusura la sessione non esiste piu'
        JsonObject measure = Program.NewMeasure("CELLA-BG-008", "pharma", 5, 55, 87);
        connection.Send("/api/telemetry", measure.ToJsonString(), "telemetry", out status);
        Check(status == 404, "dopo la chiusura atteso 404, ricevuto " + status);
    }
}
