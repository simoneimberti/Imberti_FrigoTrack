using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;
using Json.Schema;

// ATTENZIONE: questo file e' IDENTICO nel Server e nel Client.
// Se lo modifichi, copia la stessa modifica anche nell'altro progetto.

/// <summary>Un errore di validazione: quale campo e perche'.</summary>
class SchemaError
{
    public string Field = "";
    public string Message = "";
}

/// <summary>
/// Validazione dei messaggi con JSON Schema.
/// Il lavoro lo fa la libreria JsonSchema.Net (pacchetto NuGet): legge un file della cartella
/// schemas/ e controlla il messaggio con tutte le regole scritte nello schema
/// (type, required, enum, minimum, maximum, pattern, format, const, additionalProperties...).
/// In questo file NON ci sono controlli sui singoli campi: per cambiare una regola si cambia lo schema.
/// </summary>
static class SchemaValidator
{
    // Il programma gira in <progetto>/bin/Debug/net8.0: risalgo di 4 cartelle per arrivare
    // alla cartella principale (quella che contiene Server, Client e schemas)
    public static readonly string SchemasFolder =
        Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "schemas"));

    // Valida un testo JSON con il file schemas/<schemaName>.schema.json.
    // Restituisce null se il messaggio e' valido, altrimenti il primo errore trovato.
    public static SchemaError Validate(string json, string schemaName)
    {
        // 1) carico lo schema dal suo file (ogni volta: se modifichi lo schema vale subito)
        JsonSchema schema = JsonSchema.FromFile(Path.Combine(SchemasFolder, schemaName + ".schema.json"));

        // 2) leggo il JSON da controllare
        JsonNode document;
        try
        {
            document = JsonNode.Parse(json);
        }
        catch (JsonException)
        {
            return NewError("", "il testo non e' un JSON valido");
        }

        // 3) la libreria confronta il JSON con lo schema
        EvaluationOptions options = new EvaluationOptions();
        options.OutputFormat = OutputFormat.List;             // tutti i risultati in un unico elenco
        options.RequireFormatValidation = true;              // controlla anche "format" (es. date-time)
        options.Culture = CultureInfo.GetCultureInfo("it");   // messaggi di errore in italiano

        EvaluationResults result = schema.Evaluate(document, options);
        if (result.IsValid) return null;

        // 4) prendo il primo errore dell'elenco:
        //    InstanceLocation dice DOVE (es. "/temperature_c"), Errors dice PERCHE' (es. "99 e' maggiore di 40")
        foreach (EvaluationResults detail in result.Details)
        {
            if (!detail.HasErrors) continue;

            string field = detail.InstanceLocation.ToString().TrimStart('/').Replace("/", ".");
            foreach (KeyValuePair<string, string> error in detail.Errors)
            {
                return NewError(field, error.Value);
            }
        }
        return NewError("", "messaggio non valido");
    }

    static SchemaError NewError(string field, string message)
    {
        SchemaError error = new SchemaError();
        error.Field = field;
        error.Message = message;
        return error;
    }
}
